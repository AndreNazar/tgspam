const NewsPage = () => {

    return <div>
            <h1></h1>
    </div>
}

export default NewsPage