const ManualPage = () => {

    return <div>
            <h1>Как начать использование?</h1>
    </div>
}

export default ManualPage