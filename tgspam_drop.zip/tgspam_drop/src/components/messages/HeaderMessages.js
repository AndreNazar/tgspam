import { Link } from "react-router-dom"
import back_icon from '../../assets/img/back.svg'

const HeaderMessages = () => {
    return <div>
        <h1>Сообщения рассылки</h1>
        <Link className="back_func" to="/panel">
            <img src={back_icon} alt="" />
            <p>Назад</p>
        </Link>
    </div>
}

export default HeaderMessages