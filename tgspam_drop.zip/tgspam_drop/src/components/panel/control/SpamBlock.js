const SpamBlock = () => {
    return <div className='target_but spam_block'>Проверить СПАМ блок</div>
}

export default SpamBlock