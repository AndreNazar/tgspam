const Number = ({number, status}) => {

    const getNumber = () => {
        const n = number
        return "+" + n[0] + " " + n.slice(1, 4) + " " + n.slice(4, 7) + " " + n.slice(7, 9) + " " + n.slice(9, 11)
    }

    return <div className='tel'>
        <h2>{getNumber()}</h2>
        <p style={{ color: status ? "#4FCA5D" : "#ca4f4f" }}>{status ? "Запущен" : "Остановлен"}</p>
    </div>
}

export default Number