import { Link } from "react-router-dom"

const ParamMessagesBlock = ({cb}) => {
    return <Link to={"messages"} className='param'>
        <p className='title_param'>{cb.title}</p>
        <p>{cb.value}</p>
    </Link>
}

export default ParamMessagesBlock