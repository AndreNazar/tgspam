import { useDispatch, useSelector } from "react-redux"
import { OPEN_WINDOW, TOGGLE_ANSWERPHONE, TOGGLE_AUTODEBIT, TOGGLE_MENTION, TOGGLE_RANDOM_INTERVAL, TOGGLE_RANDOM_MESSAGES } from "../../../reducers/types"
import ChangeFields from "../../queries/ChangeFields"

const ParamBlock = ({ cb }) => {

    const dispatch = useDispatch()

    const getValue = () => cb.type >= 2
        ? ((cb.param
            ? "Включен"
            : "Выключен")
            + cb.value)
        : cb.value

    const getColor = () => cb.type >= 2
        ? (cb.param
            ? "#4FCA5D"
            : "#ca4f4f")
        : 'inherit'

    const number_data = useSelector(s => s.app.number_data)

    const toggleParam = () => {
        switch (cb.type) {
            case -1:
                dispatch({type: OPEN_WINDOW, payload: 'type_mailing'})
                break;
            case 0:
                dispatch({type: OPEN_WINDOW, payload: 'interval'})
                break;
            case 2:
                ChangeFields("autoresponder", +!number_data.answerphone, number_data.number)
                .then(data => data && dispatch({type: TOGGLE_ANSWERPHONE}))
                break;
            case 3:
                ChangeFields("mention", +!number_data.mention, number_data.number)
                .then(data => data && dispatch({type: TOGGLE_MENTION}))
                break;
            case 4:
                ChangeFields("interval_random_bool", +!number_data.random_interval, number_data.number)
                .then(data => data && dispatch({type: TOGGLE_RANDOM_INTERVAL}))
                break;
            case 5:
                ChangeFields("message_random_bool", +!number_data.random_messages, number_data.number)
                .then(data => data && dispatch({type: TOGGLE_RANDOM_MESSAGES}))
                break;
            case 6:
                ChangeFields("auto_pay", +!number_data.autodebit, number_data.number)
                .then(data => data && dispatch({type: TOGGLE_AUTODEBIT}))
                break;
        
            default:
                break;
        }
    }

    return <div className='param' onClick={() => toggleParam()}>
        <p className='title_param'>{cb.title}</p>
        <p style={{color: getColor()}}>{getValue()}</p>
    </div>
}

export default ParamBlock