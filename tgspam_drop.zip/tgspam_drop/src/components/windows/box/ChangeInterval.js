import { useState } from "react"
import { useDispatch, useSelector } from "react-redux"
import { CHANGE_INTERVAL, CLOSE_WINDOW } from "../../../reducers/types"
import ChangeFields from "../../queries/ChangeFields"

const ChangeInterval = () => {
    const nlinterval = useSelector(w => w.app.number_data.interval)
    const number_data = useSelector(s => s.app.number_data)
    const [interval, setInterval] = useState(nlinterval)
    const dispatch = useDispatch()

    const intervalHandler = (e) => {
        if (!e) setInterval()
        else if (isFinite(+e)) {
            if (+e >= 1 && +e <= 60) setInterval(e)
            else {
                if (+e < 1) setInterval(1)
                if (+e > 60) setInterval(60)
            }
        }
    }

    const sendInterval = () => {
        ChangeFields("interval_messages", interval || nlinterval, number_data.number)
        .then(data => data && dispatch({type: CLOSE_WINDOW}))
        dispatch({type: CHANGE_INTERVAL, payload: interval || nlinterval})
        dispatch({type: CLOSE_WINDOW})
    }

    return <div className="interval_window window_content">
        <input type="text" value={interval} onChange={(e) => intervalHandler(e.target.value)} /><span>минут</span>
        <div className="save_but" onClick={sendInterval}>Сохранить</div>
    </div>
}

export default ChangeInterval