const ContactsPage = () => {

    return <div>
            <h1>Контакты</h1>
    </div>
}

export default ContactsPage