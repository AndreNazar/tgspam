const GetUser = async (id) => {
    let response = await fetch('http://vm-c6638fea.na4u.ru:5000/get_user', {
        method: 'POST',
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            "id": id,
            "fields": ["balance"]
        })
    })
        .then((response) => response.json())

    return response.result
}

export default GetUser